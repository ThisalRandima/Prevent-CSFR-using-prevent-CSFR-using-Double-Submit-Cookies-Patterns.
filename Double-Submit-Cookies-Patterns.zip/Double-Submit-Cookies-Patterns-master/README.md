# Double-Submit-Cookies-Patterns
Cross-site Request Forgery protection in web applications via Double Submit Cookies Patterns.
Download the zip file provided. Extract the folder copy the folder to the www (if you are using WAMP). Open Wamp server or Xamp server. In Wamp server file(most of the time in C drive)there is folder called www. Open the www folder. Copy the extracted folder into the www folder. Open up the browser and type http://localhost:8080/Double_Submited_Cookies/. Blog post URL - http://chamrithcs.blogspot.com/2018/05/cross-site-request-forgery-protection_9.html
